import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _b812e402 = () => interopDefault(import('../pages/admin.vue' /* webpackChunkName: "pages/admin" */))
const _84b3dcb0 = () => interopDefault(import('../pages/auth.vue' /* webpackChunkName: "pages/auth" */))
const _421d4f60 = () => interopDefault(import('../pages/contact.vue' /* webpackChunkName: "pages/contact" */))
const _789be046 = () => interopDefault(import('../pages/faq.vue' /* webpackChunkName: "pages/faq" */))
const _106add1a = () => interopDefault(import('../pages/organizacie/index.vue' /* webpackChunkName: "pages/organizacie/index" */))
const _3b90afa9 = () => interopDefault(import('../pages/organizacie/error.vue' /* webpackChunkName: "pages/organizacie/error" */))
const _5a97ec38 = () => interopDefault(import('../pages/organizacie/success.vue' /* webpackChunkName: "pages/organizacie/success" */))
const _1fa4549b = () => interopDefault(import('../pages/organizacie/_id.vue' /* webpackChunkName: "pages/organizacie/_id" */))
const _071c85e3 = () => interopDefault(import('../pages/users/_id.vue' /* webpackChunkName: "pages/users/_id" */))
const _72873a02 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/admin",
    component: _b812e402,
    name: "admin"
  }, {
    path: "/auth",
    component: _84b3dcb0,
    name: "auth"
  }, {
    path: "/contact",
    component: _421d4f60,
    name: "contact"
  }, {
    path: "/faq",
    component: _789be046,
    name: "faq"
  }, {
    path: "/organizacie",
    component: _106add1a,
    name: "organizacie"
  }, {
    path: "/organizacie/error",
    component: _3b90afa9,
    name: "organizacie-error"
  }, {
    path: "/organizacie/success",
    component: _5a97ec38,
    name: "organizacie-success"
  }, {
    path: "/organizacie/:id",
    component: _1fa4549b,
    name: "organizacie-id"
  }, {
    path: "/users/:id?",
    component: _071c85e3,
    name: "users-id"
  }, {
    path: "/",
    component: _72873a02,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
