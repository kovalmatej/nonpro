# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<AboutUs>` | `<about-us>` (components/AboutUs/index.vue)
- `<Auth>` | `<auth>` (components/Auth/index.vue)
- `<Admin>` | `<admin>` (components/Admin/index.vue)
- `<Contact>` | `<contact>` (components/Contact/index.vue)
- `<Error>` | `<error>` (components/Error/index.vue)
- `<Faq>` | `<faq>` (components/Faq/index.vue)
- `<Footer>` | `<footer>` (components/Footer/index.vue)
- `<GlobalButton>` | `<global-button>` (components/Global/GlobalButton.vue)
- `<GlobalPagination>` | `<global-pagination>` (components/Global/Pagination.vue)
- `<HeroSponsored>` | `<hero-sponsored>` (components/Hero/Sponsored.vue)
- `<Hero>` | `<hero>` (components/Hero/index.vue)
- `<Navigation>` | `<navigation>` (components/Navigation/index.vue)
- `<NonProfitPreview>` | `<non-profit-preview>` (components/NonProfitPreview/index.vue)
- `<NonProfitsList>` | `<non-profits-list>` (components/NonProfits/List.vue)
- `<NonProfitsSearch>` | `<non-profits-search>` (components/NonProfits/Search.vue)
- `<NonProfitsSideFilter>` | `<non-profits-side-filter>` (components/NonProfits/SideFilter.vue)
- `<NonProfits>` | `<non-profits>` (components/NonProfits/index.vue)
- `<OrganizationInfo>` | `<organization-info>` (components/Organization/OrganizationInfo.vue)
- `<Organization>` | `<organization>` (components/Organization/index.vue)
- `<QuestionsFormChangeQuestionArrow>` | `<questions-form-change-question-arrow>` (components/QuestionsForm/ChangeQuestionArrow.vue)
- `<QuestionsFormOption>` | `<questions-form-option>` (components/QuestionsForm/FormOption.vue)
- `<QuestionsFormOptions>` | `<questions-form-options>` (components/QuestionsForm/FormOptions.vue)
- `<QuestionsFormProgressBar>` | `<questions-form-progress-bar>` (components/QuestionsForm/ProgressBar.vue)
- `<QuestionsForm>` | `<questions-form>` (components/QuestionsForm/index.vue)
- `<Recommended>` | `<recommended>` (components/Recommended/index.vue)
- `<SimilarOrganization>` | `<similar-organization>` (components/SimilarOrganizations/SimilarOrganization.vue)
- `<SimilarOrganizations>` | `<similar-organizations>` (components/SimilarOrganizations/index.vue)
- `<Sponsored>` | `<sponsored>` (components/Sponsored/index.vue)
- `<Success>` | `<success>` (components/Success/index.vue)
- `<User>` | `<user>` (components/User/index.vue)
