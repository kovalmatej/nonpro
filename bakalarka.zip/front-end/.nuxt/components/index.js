import { wrapFunctional } from './utils'

export { default as AboutUs } from '../../components/AboutUs/index.vue'
export { default as Auth } from '../../components/Auth/index.vue'
export { default as Admin } from '../../components/Admin/index.vue'
export { default as Contact } from '../../components/Contact/index.vue'
export { default as Error } from '../../components/Error/index.vue'
export { default as Faq } from '../../components/Faq/index.vue'
export { default as Footer } from '../../components/Footer/index.vue'
export { default as GlobalButton } from '../../components/Global/GlobalButton.vue'
export { default as GlobalPagination } from '../../components/Global/Pagination.vue'
export { default as HeroSponsored } from '../../components/Hero/Sponsored.vue'
export { default as Hero } from '../../components/Hero/index.vue'
export { default as Navigation } from '../../components/Navigation/index.vue'
export { default as NonProfitPreview } from '../../components/NonProfitPreview/index.vue'
export { default as NonProfitsList } from '../../components/NonProfits/List.vue'
export { default as NonProfitsSearch } from '../../components/NonProfits/Search.vue'
export { default as NonProfitsSideFilter } from '../../components/NonProfits/SideFilter.vue'
export { default as NonProfits } from '../../components/NonProfits/index.vue'
export { default as OrganizationInfo } from '../../components/Organization/OrganizationInfo.vue'
export { default as Organization } from '../../components/Organization/index.vue'
export { default as QuestionsFormChangeQuestionArrow } from '../../components/QuestionsForm/ChangeQuestionArrow.vue'
export { default as QuestionsFormOption } from '../../components/QuestionsForm/FormOption.vue'
export { default as QuestionsFormOptions } from '../../components/QuestionsForm/FormOptions.vue'
export { default as QuestionsFormProgressBar } from '../../components/QuestionsForm/ProgressBar.vue'
export { default as QuestionsForm } from '../../components/QuestionsForm/index.vue'
export { default as Recommended } from '../../components/Recommended/index.vue'
export { default as SimilarOrganization } from '../../components/SimilarOrganizations/SimilarOrganization.vue'
export { default as SimilarOrganizations } from '../../components/SimilarOrganizations/index.vue'
export { default as Sponsored } from '../../components/Sponsored/index.vue'
export { default as Success } from '../../components/Success/index.vue'
export { default as User } from '../../components/User/index.vue'

export const LazyAboutUs = import('../../components/AboutUs/index.vue' /* webpackChunkName: "components/about-us" */).then(c => wrapFunctional(c.default || c))
export const LazyAuth = import('../../components/Auth/index.vue' /* webpackChunkName: "components/auth" */).then(c => wrapFunctional(c.default || c))
export const LazyAdmin = import('../../components/Admin/index.vue' /* webpackChunkName: "components/admin" */).then(c => wrapFunctional(c.default || c))
export const LazyContact = import('../../components/Contact/index.vue' /* webpackChunkName: "components/contact" */).then(c => wrapFunctional(c.default || c))
export const LazyError = import('../../components/Error/index.vue' /* webpackChunkName: "components/error" */).then(c => wrapFunctional(c.default || c))
export const LazyFaq = import('../../components/Faq/index.vue' /* webpackChunkName: "components/faq" */).then(c => wrapFunctional(c.default || c))
export const LazyFooter = import('../../components/Footer/index.vue' /* webpackChunkName: "components/footer" */).then(c => wrapFunctional(c.default || c))
export const LazyGlobalButton = import('../../components/Global/GlobalButton.vue' /* webpackChunkName: "components/global-button" */).then(c => wrapFunctional(c.default || c))
export const LazyGlobalPagination = import('../../components/Global/Pagination.vue' /* webpackChunkName: "components/global-pagination" */).then(c => wrapFunctional(c.default || c))
export const LazyHeroSponsored = import('../../components/Hero/Sponsored.vue' /* webpackChunkName: "components/hero-sponsored" */).then(c => wrapFunctional(c.default || c))
export const LazyHero = import('../../components/Hero/index.vue' /* webpackChunkName: "components/hero" */).then(c => wrapFunctional(c.default || c))
export const LazyNavigation = import('../../components/Navigation/index.vue' /* webpackChunkName: "components/navigation" */).then(c => wrapFunctional(c.default || c))
export const LazyNonProfitPreview = import('../../components/NonProfitPreview/index.vue' /* webpackChunkName: "components/non-profit-preview" */).then(c => wrapFunctional(c.default || c))
export const LazyNonProfitsList = import('../../components/NonProfits/List.vue' /* webpackChunkName: "components/non-profits-list" */).then(c => wrapFunctional(c.default || c))
export const LazyNonProfitsSearch = import('../../components/NonProfits/Search.vue' /* webpackChunkName: "components/non-profits-search" */).then(c => wrapFunctional(c.default || c))
export const LazyNonProfitsSideFilter = import('../../components/NonProfits/SideFilter.vue' /* webpackChunkName: "components/non-profits-side-filter" */).then(c => wrapFunctional(c.default || c))
export const LazyNonProfits = import('../../components/NonProfits/index.vue' /* webpackChunkName: "components/non-profits" */).then(c => wrapFunctional(c.default || c))
export const LazyOrganizationInfo = import('../../components/Organization/OrganizationInfo.vue' /* webpackChunkName: "components/organization-info" */).then(c => wrapFunctional(c.default || c))
export const LazyOrganization = import('../../components/Organization/index.vue' /* webpackChunkName: "components/organization" */).then(c => wrapFunctional(c.default || c))
export const LazyQuestionsFormChangeQuestionArrow = import('../../components/QuestionsForm/ChangeQuestionArrow.vue' /* webpackChunkName: "components/questions-form-change-question-arrow" */).then(c => wrapFunctional(c.default || c))
export const LazyQuestionsFormOption = import('../../components/QuestionsForm/FormOption.vue' /* webpackChunkName: "components/questions-form-option" */).then(c => wrapFunctional(c.default || c))
export const LazyQuestionsFormOptions = import('../../components/QuestionsForm/FormOptions.vue' /* webpackChunkName: "components/questions-form-options" */).then(c => wrapFunctional(c.default || c))
export const LazyQuestionsFormProgressBar = import('../../components/QuestionsForm/ProgressBar.vue' /* webpackChunkName: "components/questions-form-progress-bar" */).then(c => wrapFunctional(c.default || c))
export const LazyQuestionsForm = import('../../components/QuestionsForm/index.vue' /* webpackChunkName: "components/questions-form" */).then(c => wrapFunctional(c.default || c))
export const LazyRecommended = import('../../components/Recommended/index.vue' /* webpackChunkName: "components/recommended" */).then(c => wrapFunctional(c.default || c))
export const LazySimilarOrganization = import('../../components/SimilarOrganizations/SimilarOrganization.vue' /* webpackChunkName: "components/similar-organization" */).then(c => wrapFunctional(c.default || c))
export const LazySimilarOrganizations = import('../../components/SimilarOrganizations/index.vue' /* webpackChunkName: "components/similar-organizations" */).then(c => wrapFunctional(c.default || c))
export const LazySponsored = import('../../components/Sponsored/index.vue' /* webpackChunkName: "components/sponsored" */).then(c => wrapFunctional(c.default || c))
export const LazySuccess = import('../../components/Success/index.vue' /* webpackChunkName: "components/success" */).then(c => wrapFunctional(c.default || c))
export const LazyUser = import('../../components/User/index.vue' /* webpackChunkName: "components/user" */).then(c => wrapFunctional(c.default || c))
