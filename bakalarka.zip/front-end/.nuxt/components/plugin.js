import Vue from 'vue'
import { wrapFunctional } from './utils'

const components = {
  AboutUs: () => import('../../components/AboutUs/index.vue' /* webpackChunkName: "components/about-us" */).then(c => wrapFunctional(c.default || c)),
  Auth: () => import('../../components/Auth/index.vue' /* webpackChunkName: "components/auth" */).then(c => wrapFunctional(c.default || c)),
  Admin: () => import('../../components/Admin/index.vue' /* webpackChunkName: "components/admin" */).then(c => wrapFunctional(c.default || c)),
  Contact: () => import('../../components/Contact/index.vue' /* webpackChunkName: "components/contact" */).then(c => wrapFunctional(c.default || c)),
  Error: () => import('../../components/Error/index.vue' /* webpackChunkName: "components/error" */).then(c => wrapFunctional(c.default || c)),
  Faq: () => import('../../components/Faq/index.vue' /* webpackChunkName: "components/faq" */).then(c => wrapFunctional(c.default || c)),
  Footer: () => import('../../components/Footer/index.vue' /* webpackChunkName: "components/footer" */).then(c => wrapFunctional(c.default || c)),
  GlobalButton: () => import('../../components/Global/GlobalButton.vue' /* webpackChunkName: "components/global-button" */).then(c => wrapFunctional(c.default || c)),
  GlobalPagination: () => import('../../components/Global/Pagination.vue' /* webpackChunkName: "components/global-pagination" */).then(c => wrapFunctional(c.default || c)),
  HeroSponsored: () => import('../../components/Hero/Sponsored.vue' /* webpackChunkName: "components/hero-sponsored" */).then(c => wrapFunctional(c.default || c)),
  Hero: () => import('../../components/Hero/index.vue' /* webpackChunkName: "components/hero" */).then(c => wrapFunctional(c.default || c)),
  Navigation: () => import('../../components/Navigation/index.vue' /* webpackChunkName: "components/navigation" */).then(c => wrapFunctional(c.default || c)),
  NonProfitPreview: () => import('../../components/NonProfitPreview/index.vue' /* webpackChunkName: "components/non-profit-preview" */).then(c => wrapFunctional(c.default || c)),
  NonProfitsList: () => import('../../components/NonProfits/List.vue' /* webpackChunkName: "components/non-profits-list" */).then(c => wrapFunctional(c.default || c)),
  NonProfitsSearch: () => import('../../components/NonProfits/Search.vue' /* webpackChunkName: "components/non-profits-search" */).then(c => wrapFunctional(c.default || c)),
  NonProfitsSideFilter: () => import('../../components/NonProfits/SideFilter.vue' /* webpackChunkName: "components/non-profits-side-filter" */).then(c => wrapFunctional(c.default || c)),
  NonProfits: () => import('../../components/NonProfits/index.vue' /* webpackChunkName: "components/non-profits" */).then(c => wrapFunctional(c.default || c)),
  OrganizationInfo: () => import('../../components/Organization/OrganizationInfo.vue' /* webpackChunkName: "components/organization-info" */).then(c => wrapFunctional(c.default || c)),
  Organization: () => import('../../components/Organization/index.vue' /* webpackChunkName: "components/organization" */).then(c => wrapFunctional(c.default || c)),
  QuestionsFormChangeQuestionArrow: () => import('../../components/QuestionsForm/ChangeQuestionArrow.vue' /* webpackChunkName: "components/questions-form-change-question-arrow" */).then(c => wrapFunctional(c.default || c)),
  QuestionsFormOption: () => import('../../components/QuestionsForm/FormOption.vue' /* webpackChunkName: "components/questions-form-option" */).then(c => wrapFunctional(c.default || c)),
  QuestionsFormOptions: () => import('../../components/QuestionsForm/FormOptions.vue' /* webpackChunkName: "components/questions-form-options" */).then(c => wrapFunctional(c.default || c)),
  QuestionsFormProgressBar: () => import('../../components/QuestionsForm/ProgressBar.vue' /* webpackChunkName: "components/questions-form-progress-bar" */).then(c => wrapFunctional(c.default || c)),
  QuestionsForm: () => import('../../components/QuestionsForm/index.vue' /* webpackChunkName: "components/questions-form" */).then(c => wrapFunctional(c.default || c)),
  Recommended: () => import('../../components/Recommended/index.vue' /* webpackChunkName: "components/recommended" */).then(c => wrapFunctional(c.default || c)),
  SimilarOrganization: () => import('../../components/SimilarOrganizations/SimilarOrganization.vue' /* webpackChunkName: "components/similar-organization" */).then(c => wrapFunctional(c.default || c)),
  SimilarOrganizations: () => import('../../components/SimilarOrganizations/index.vue' /* webpackChunkName: "components/similar-organizations" */).then(c => wrapFunctional(c.default || c)),
  Sponsored: () => import('../../components/Sponsored/index.vue' /* webpackChunkName: "components/sponsored" */).then(c => wrapFunctional(c.default || c)),
  Success: () => import('../../components/Success/index.vue' /* webpackChunkName: "components/success" */).then(c => wrapFunctional(c.default || c)),
  User: () => import('../../components/User/index.vue' /* webpackChunkName: "components/user" */).then(c => wrapFunctional(c.default || c))
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
