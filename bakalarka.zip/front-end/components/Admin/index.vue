<template>
	<div class="">
		admin
	</div>
</template>

<script>
export default {
	name: "Admin",
}
</script>

<style lang="sass" scoped>

</style>
