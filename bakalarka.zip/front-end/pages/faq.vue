<template>
  <div>
    <Faq />
    <Footer />
  </div>
</template>

<script>

export default {
  layout: "clasic"
}
</script>
