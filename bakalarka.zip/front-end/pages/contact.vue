<template>
  <div>
		<Contact />
    <Footer />
  </div>
</template>

<script>
export default {
  layout: "clasic"
}
</script>
