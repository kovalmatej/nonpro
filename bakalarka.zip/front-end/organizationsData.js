const organizations = [
	{
		id: 0,
		title: "Alexsma",
		ICO: "52459870",
		city: "Košice - mestská časť Sídlisko KVP"
	},
	{
		id: 1,
		title: "Nádej pre Damiánka",
		ICO: "53002938",
		city: "Kátlovce"
	},
	{
		id: 2,
		title: "Spolok Permon Marianka",
		ICO: "37929674",
		city: "Marianka"
	},
	{
		id: 3,
		title: "Alexsma",
		ICO: "52459870",
		city: "Košice - mestská časť Sídlisko KVP"
	},
	{
		id: 4,
		title: "Nádej pre Damiánka",
		ICO: "53002938",
		city: "Kátlovce"
	},
	{
		id: 5,
		title: "Spolok Permon Marianka",
		ICO: "37929674",
		city: "Marianka"
	},
	{
		id: 6,
		title: "Alexsma",
		ICO: "52459870",
		city: "Košice - mestská časť Sídlisko KVP"
	},
	{
		id: 7,
		title: "Nádej pre Damiánka",
		ICO: "53002938",
		city: "Kátlovce"
	},
	{
		id: 8,
		title: "Spolok Permon Marianka",
		ICO: "37929674",
		city: "Marianka"
	},
	{
		id: 9,
		title: "Alexsma",
		ICO: "52459870",
		city: "Košice - mestská časť Sídlisko KVP"
	},
	{
		id: 10,
		title: "Nádej pre Damiánka",
		ICO: "53002938",
		city: "Kátlovce"
	},
	{
		id: 11,
		title: "Spolok Permon Marianka",
		ICO: "37929674",
		city: "Marianka"
	}
]

export default organizations 
